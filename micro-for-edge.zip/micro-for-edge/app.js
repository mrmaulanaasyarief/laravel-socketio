const express = require('express')
const { createServer } = require('http')
const mysql = require('mysql');
const {SerialPort} = require('serialport');
const {ReadlineParser} = require('@serialport/parser-readline');
const { autoDetect } = require('@serialport/bindings-cpp')
const io = require('socket.io-client');
const axios = require('axios');
const cors = require('cors');
const Pusher = require("pusher");

const pusher = new Pusher({
    appId: '1690322',
    key: '54276e277a7264e5bb57',
    secret: 'b56c89f88e7a42ef76e8',
    useTLS: 'https',
    cluster: 'ap1', // if `host` is present, it will override the `cluster` option.
    host: '', // optional, defaults to api.pusherapp.com
    port: '443', // optional, defaults to 80 for non-TLS connections and 443 for TLS connections
});

// Connect to Laravel WebSocket server
const socket = io('http://localhost:6001', {
  path: '/socket.io',
  transports: ['websocket'],
});

const app = express()
const httpServer = createServer(app)
const bodyParser = require('body-parser')
let portStatus = false
let wsStatus = false
let serialPorts = []
const Binding = autoDetect()
let dataPayload

SerialPort.list().then(function(ports) {
  // Open a serial port for each available port
  ports.forEach(function(port) {
    const serialPort = new SerialPort({ path: port.path,  baudRate: 9600, autoOpen: false })

    serialPorts.push(serialPort)

    // // Listen for data on the port
    // serialPort.on('data', function(data) {
    //   console.log('Data from port', port.path, ':', data.toString());
    // });
  });
});

app.use(cors());
app.use(bodyParser.json())

//IMPORT ROUTES
const postsRoute = require('./routes/posts');

app.use('/posts', postsRoute)

//ROUTES
app.get('/', async (req, res) => {
  res.sendFile('views/index.html', {root: __dirname })
})

app.get('/get', async (req, res) => {
  const ports = await SerialPort.list()
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader("Content-Type", "application/json")
  res.json(
    {
      ok: true,
      ports: ports.map((val, i) => {
        return {
          path: val.path,
          isOpen: false
        }
      })
    }
  )
  res.end()
})

app.post('/open', (req, res) => {
  console.log(req.body.port);

  const portIndex = serialPorts.findIndex(p => p.path === req.body.port);
  console.log(portIndex);

  if (portIndex === -1) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.status(400)
    res.send({
      error: {
        message: "Port Tidak ditemukan"
      }
    });
    return console.log('Error opening port: ', "Port tidak ditemukan")
  }

  const port = serialPorts[portIndex]

  if (port.isOpen) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.status(400)
    res.send({
      error: {
        message: "Port already open"
      }
    });
    return console.log('Error opening port: ', "Port already open")
  }
  port.open((err) => {
    console.log('Port open');
    let errMessage = null
    if (err) {
      console.log(err);
      res.status(500)
      res.send({
        error: {
          message: err.message
        }
      });
      return console.log('Error opening port: ', err.message)
    }
    res.json({status: 'ok'})
    res.end()
  })

  // port listening
  const parser = port.pipe(new ReadlineParser({ delimiter: '\n' }));
  parser.on('data', data =>{
    console.log('got word from arduino:');
    // const val = JSON.parse(data)

    // const contoh = "-6.967658000,107.658933667,734.30,1.57,284.07,119.80,11.80,1494.00,0,Siap,-244,1328,-14776,-115,213,260,*"
    // let regex = /^\*,([0-9]+(;[0-9]+)+),([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,([+-]?(?=\.\d|\d)(?:\d+)?(?:\.?\d*))(?:[Ee]([+-]?\d+))?,#$/i;
    // isValid =  regex.test(data);
    console.log(data)
    const dataSplitted = data.split(",")
    // console.log(dataSplitted.length)

    var areAllNotNull = dataSplitted.every(function(i) { return i !== null; });

    if (dataSplitted.length == 26 && areAllNotNull) {
        var flight_code_id = null;
        axios.get('http://laravel-socketio.test/api/telemetri_logs/selected')
        .then(function (response) {
            // handle success
            console.log(response.data.id);
            flight_code_id = response.data.id;
        });

        let [header, tPayload, lat, long, alt, sog, cog, arus, tegangan, daya, klasifikasi, ax, ay, az, gx, gy, gz, mx, my, mz, roll, pitch, yaw, suhu, humidity, footer] = data.split(",");
        console.log(tPayload.replace(/;/g, ':'), lat, long, alt, sog, cog, arus, tegangan, daya, klasifikasi, ax, ay, az, gx, gy, gz, mx, my, mz, roll, pitch, yaw, suhu, humidity);
        axios.post('http://laravel-socketio.test/api/telemetri_logs', {
            tPayload : tPayload.replace(/;/g, ':'),
            flight_code_id: flight_code_id,
            lat : lat,
            long : long,
            alt : alt,
            sog : sog,
            cog : cog,
            arus : arus,
            tegangan : tegangan,
            daya : daya,
            klasifikasi : klasifikasi,
            ax : ax,
            ay : ay,
            az : az,
            gx : gx,
            gy : gy,
            gz : gz,
            mx : mx,
            my : my,
            mz : mz,
            roll : roll,
            pitch : pitch,
            yaw : yaw,
            suhu : suhu,
            humidity : humidity
        });
    }

    });
})

app.post('/close', (req, res) => {
  console.log(req.body);
  res.setHeader('Access-Control-Allow-Origin', '*');

  const portIndex = serialPorts.findIndex(p => p.path === req.body.port);

  if (portIndex === -1) {
    res.status(400)
    res.send({
      error: {
        message: "Port Tidak ditemukan"
      }
    });
    return console.log('Error opening port: ', "Port tidak ditemukan")
  }

  const port = serialPorts[portIndex]

  if (!port.isOpen) {
    res.status(400)
    res.send({
      error: {
        message: "Port already close"
      }
    });
    return console.log('Error opening port: ', "Port already close")
  }

  port.close((err) => {
    portStatus = false;
    if (err) {
      console.log(err);
      res.status(500)
      res.send({
        error: {
          message: err.message
        }
      });
      return console.log('Error opening port: ', err.message)
    }

    console.log('Port close');
    console.log(err);
    res.json({status: 'ok'})
    res.end()
  })
})
app.post('/send', (req, res) => {
  console.log(req.body);
  if (portStatus) {
    const uniqueCode = req.body.code
    const messages = 'SETCODE,'+uniqueCode+',*'
    port.write(' '+messages, function(err) {
      if (err) {
        return console.log('Error on write: ', err.message)
      }
      console.log('message written')
    })
  }
})

app.post('/set-led', (req, res) => {
  console.log(req.body);
  if (portStatus) {
    const mode = req.body.mode
    const messages = 'SETLED,'+mode+',*'
    port.write(' '+messages, function(err) {
      if (err) {
        return console.log('Error on write: ', err.message)
      }
      console.log('message written')
    })
  }
})

//START LISTENING
app.listen(7979, function () { console.log('Server started on port 7979')})
